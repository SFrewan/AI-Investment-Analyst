namespace AI.Investment.Application.Common;

/// <summary>A page of results together with the total available.</summary>
public sealed record PagedResult<T>(IReadOnlyList<T> Items, int TotalCount, int Skip, int Take)
{
    public static PagedResult<T> Empty(int skip, int take) => new([], 0, skip, take);
}
